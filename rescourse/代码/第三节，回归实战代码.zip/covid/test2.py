




# indices = np.argsort(scores)[::-1]
a = [1,2,3,4,5]
print(a)
print(a[::-1])